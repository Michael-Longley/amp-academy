# AMP ACADEMY — COURSE 2: JOURNEYMAN ELECTRICIAN NEC 2017
## Open edX OLX Package — Tutor v21 / Redwood

---

## IMPORT INSTRUCTIONS

### Prerequisites
1. Tutor v21 / Redwood on Digital Ocean
2. SendGrid SMTP configured
3. NEC 2017 Content Library imported first

### Import This Course
```
Studio → Home → Import → Upload course_02_journeyman_nec2017.tar.gz
```

### Configure After Import
1. Content Groups: state_pa, state_nj, state_de, state_md, state_ny, state_ct
2. Add banner image: 1200x400px JPG to static/
3. Load SendGrid templates from static/emails/

---

## COURSE STRUCTURE

| Module | Topic | Lessons | Threshold |
|--------|-------|---------|-----------|
| Orientation | Exam overview, navigator | 5 | N/A |
| 1 | NEC structure + exam strategy | 9 | 75% |
| 2 | Wiring and protection (200-285) | 10 | 75% |
| 3 | Load calculations (220) | 10 | 75% |
| 4 | Services (230) | 9 | 75% |
| 5 | Grounding and bonding (250) | 10 | 75% |
| 6 | Wiring methods (300-398) | 12 | 75% |
| 7 | Equipment general use (400-490) | 9 | 75% |
| 8 | Motors (430) deep dive | 10 | 75% |
| 9 | Special occupancies (500-590) | 10 | 75% |
| 10 | Special equipment (600-695) | 7 | 75% |
| 11 | Special conditions (700-760) | 7 | 75% |
| 12 | Calculations mastery | 13 | 75% |
| 13 | Exam traps and strategy | 8 | 75% |
| 14 | State-specific (PA/NJ/DE/MD/NY/CT) | 6 | 75% |
| Final | 80-question assessment | 1 | 80% |

Total: 300-400 self-paced credit hours

---

## KEY DIFFERENTIATORS FROM COURSE 4 (VOCATIONAL)

- No math scaffolding — calculations introduced directly
- Grade 10-11 professional reading level throughout
- Commercial wiring scenarios added
- All NEC chapters covered at application depth
- Bloom's taxonomy: Apply, Analyze, Evaluate dominant
- Exam-aligned question weighting (PSI Journeyman distribution)
- Timed drill awareness built in from Module 3

---

## DIFFERENTIATION FROM COURSE 1 (MASTER)

This course covers the Journeyman exam scope.
Course 1 (Master) adds:
- Plan review and commercial design scenarios
- AHJ inspection scenarios
- Paralleled conductor calculations
- Complex transformer bank sizing
- Advanced commercial load calculations
- Higher Bloom's levels throughout

