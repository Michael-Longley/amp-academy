# AMP ACADEMY — SENDGRID NOTIFICATION TEMPLATES
# Course 2: Journeyman Electrician NEC 2017
# ==========================================

## TEMPLATE 1: ENROLLMENT WELCOME
Subject: Welcome to Amp Academy — Your Journeyman Exam Preparation Begins Now

Hi {first_name},

You have enrolled in **Amp Academy Journeyman Electrician — NEC 2017**.

Your target: the **Journeyman Electrician licensing exam** — 80 questions, 4 hours, open book, 70% passing score. This course trains you to exceed that standard.

**What to do first:**
1. Tab your NEC 2017 book — Lesson 1.5 covers Perry's 10-tab system
2. Select your state in the Orientation survey
3. Complete Module 1 before anything else — exam strategy is as important as content

**Your course standard:** 75% per module. 80% on the final. These are harder than the real exam by design.

Let's get your license.

— Amp Academy | courses@ampacademy.com

---

## TEMPLATE 2: MODULE QUIZ FAILED
Subject: Module {module_number} not passed — remediation assigned

Hi {first_name},

Your Module {module_number} score: **{score}%** — below the 75% threshold.

**Topics requiring attention:**
{weak_topics}

A targeted remediation has been assigned. Complete it before your retake. Each retake uses new questions from our problem bank.

[Start Remediation →] {remediation_url}

Persistence is the difference between passing and failing the real exam.

— Amp Academy

---

## TEMPLATE 3: CALCULATION DRILL BELOW 75%
Subject: Calculation accuracy needs work — remediation assigned

Hi {first_name},

Your score on the **{drill_name}** was {score}%.

Calculation errors on the real exam cost points directly. We have assigned a targeted calculation remediation focused on exactly where you lost points.

**Common calculation mistakes to review:**
- FLC vs FLA — always use NEC table FLC for conductors
- Demand factor decimal conversion (35% = 0.35, not 35)
- Rounding down on conduit fill, never up

[Continue Remediation →] {remediation_url}

— Amp Academy

---

## TEMPLATE 4: MODULE PASSED
Subject: Module {module_number} cleared — {next_module} is unlocked

Hi {first_name},

**Module {module_number}: PASSED — {score}%**

**{next_module}** is now unlocked.

Overall progress: {percent_complete}% complete.

[Continue to {next_module} →] {next_url}

— Amp Academy

---

## TEMPLATE 5: 7-DAY INACTIVITY
Subject: Your Journeyman exam preparation has stalled — resume today

Hi {first_name},

Seven days without activity on your Journeyman course.

Exam dates at PSI and Prometric testing centers book up weeks in advance. Every day you delay your preparation is a day you push back your license.

Current position: {current_module}, {percent_complete}% complete.

[Return to Training →] {course_url}

— Amp Academy

---

## TEMPLATE 6: MODULE 8 (MOTORS) COMPLETE
Subject: Motor calculations are now your strength — keep going

Hi {first_name},

You have completed **Module 8 — Motors**.

Motor calculations are one of the highest-weighted topics on the Journeyman exam. Completing this module with a passing score means you have mastered one of the most frequently tested skill sets.

Next: **Module 9 — Special Occupancies** — hazardous locations, sealing fittings, and classified areas.

[Continue to Module 9 →] {next_url}

— Amp Academy

---

## TEMPLATE 7: MODULE 12 COMPLETE (CALCULATIONS MASTERY)
Subject: All calculation types mastered — exam readiness improving

Hi {first_name},

**Module 12 — Calculations Mastery: COMPLETE**

You have now drilled every calculation type that appears on the Journeyman exam:
✓ Ohm's Law and Power
✓ Voltage Drop (single and three-phase)
✓ Box Fill and Conduit Fill
✓ Motor conductor and OCPD sizing
✓ GEC, EGC, and Bonding Jumper sizing
✓ Transformer calculations
✓ Load calculations (standard and optional)
✓ Ampacity correction and bundling

Two modules remain: Exam Strategy (Module 13) and State Requirements (Module 14). Then your final assessment.

[Continue to Module 13 →] {next_url}

— Amp Academy

---

## TEMPLATE 8: FINAL ASSESSMENT PASSED
Subject: Journeyman course complete — your license exam is next

Hi {first_name},

**Final Assessment Score: {score}%**

You have completed **Amp Academy Journeyman Electrician — NEC 2017**.

Your certificate is available now.

[Download Certificate →] {certificate_url}

**Your next step:** Enroll in **Course 11 — Exam Simulator 2017** to take full timed mock exams simulating the actual PSI/Prometric Journeyman exam before you schedule your real test.

[Enroll in Exam Simulator →] {simulator_url}

— Amp Academy | ampacademy.com

---

## TEMPLATE 9: FINAL ASSESSMENT FAILED
Subject: Final assessment not passed — targeted review plan inside

Hi {first_name},

Your Final Assessment score: **{score}%** — below the 80% threshold.

This is not a setback. It is precise information about exactly what to review before your real exam.

**Your weakest areas:**
{weak_areas_list}

A remediation path has been assigned for each area. Complete it and retake.

Your real exam passing score is 70%. You are training to 80%. You will get there.

[Start Final Remediation →] {remediation_url}

— Amp Academy

